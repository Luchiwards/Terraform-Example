import json

def handler(event, context):
    # Process SQS messages (emergency)
    for record in event.get("Records", []):
        _body = record.get("body")
    return {"statusCode": 200}
