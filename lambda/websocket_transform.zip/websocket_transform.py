import json

def handler(event, context):
    # Echo back message or perform transformation
    return {
        "statusCode": 200,
        "body": json.dumps({"ok": True, "event": event.get("requestContext", {}).get("routeKey", "default")})
    }
